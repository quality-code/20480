﻿//An old - style function expression

const combineText = function (text) {
    return "Bienvenido a JavaScript " + text;
};

let combineText2 = (text) => {
    return "Bienvenido a JavaScript " + text;
};

//Omit parenthesis from one-parameter function
let combineText3 = text => {
    return "I love to " + text;
};

//Omit the return keyword and the curly brackets
let combineText4 = text => "I love to " + text;

//Parameterless arrow function
let logToConsole = () => console.log("logging…");

//***************PROMISE******************
//server URL
const personApiUrl = "https://randomuser.me/api/?results=3";

let getRemoteData = url => new Promise((resolve, reject) => {
    let request = new XMLHttpRequest();
    request.onload = () => {
        if (request.status === 200) {
            resolve(request.response);
        }
        else {
            reject(Error(request.statusText));
        }
    };
    // Handle network errors
    request.onerror = () => {
        reject(Error("Network error occurred"));
    };
    request.open("GET", url);
    request.send();
});

let promiseData = () => {
    getRemoteData(personApiUrl)
        .then(data => console.log("success!", data))
        .catch(error => console.log("failed!", error));
};
